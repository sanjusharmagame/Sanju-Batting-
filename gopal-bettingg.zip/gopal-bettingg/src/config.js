export const firebaseConfig = {
  apiKey: "AIzaSyBrquk8FdPXfheFIuwhlBT3IEWpHe7-iWE",
  authDomain: "gopalgame-13553.firebaseapp.com",
  projectId: "gopalgame-13553",
  storageBucket: "gopalgame-13553.appspot.com",
  messagingSenderId: "114051811205",
  appId: "1:114051811205:web:9282e9d0314f8ad95166ec",
  measurementId: "G-V52EEYB6W4"
};
