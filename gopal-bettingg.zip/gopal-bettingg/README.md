# Gopal Betting
A color trading game like Club91, built with React and Firebase.